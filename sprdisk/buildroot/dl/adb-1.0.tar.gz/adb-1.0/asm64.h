//#include <errno.h>
#ifndef _ARM64_ASM_H_
#define _ARM64_ASM_H_
#define MAX_ERRNO 4095

#define __NR_OABI_SYSCALL_BASE 0
#define __NR_SYSCALL_BASE __NR_OABI_SYSCALL_BASE

/* WARNING: DO NOT EDIT, AUTO-GENERATED CODE - SEE TOP FOR INSTRUCTIONS */
#define REBOOT_IDX	142
#define __NR_reboot (__NR_SYSCALL_BASE+ REBOOT_IDX)

#ifndef _ALIGN_TEXT
# define _ALIGN_TEXT .align 0
#endif

#if defined(__ELF__) && defined(PIC)
#define PIC_SYM(x,y) x ## ( ## y ## )
#else
#define PIC_SYM(x,y) x
#endif

#define __bionic_asm_custom_entry(f) /* .fnstart */
#define __bionic_asm_custom_end(f) /* .fnend */

/* this is for arm32
* #define __bionic_asm_function_type #function
*/
#define __bionic_asm_function_type %function

#define ENTRY(f) \
    .text; \
    .globl f; \
    _ALIGN_TEXT; \
    .type f, __bionic_asm_function_type; \
    f: \
    __bionic_asm_custom_entry(f); \
    .cfi_startproc \

#define END(f) \
    .cfi_endproc; \
    .size f, .-f; \
    __bionic_asm_custom_end(f) \

/* Like ENTRY, but with hidden visibility. */
#define ENTRY_PRIVATE(f) \
    ENTRY(f); \
    .hidden f \

/*
// This one is for internal use only and used by both LP32 and LP64 assembler.
extern "C" __LIBC_HIDDEN__ long __set_errno_internal(int n) {
	errno = n;
    return -1;
}
*/

#endif