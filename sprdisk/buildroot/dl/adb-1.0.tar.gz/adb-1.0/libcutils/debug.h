#ifndef __DEBUG_H
#define __DEBUG_H
#  define  D(...)                                      				\
        do {                                           				\
                printf( "%s::%s():", __FILE__, __FUNCTION__);       \
                printf( __VA_ARGS__ );        						\
        } while (0)
#endif