#include <stdio.h>
#include <stdlib.h>
#include <stdint.h>
#include <errno.h>
#include <unistd.h>
#include <string.h>
#include <time.h>
#include <fcntl.h>
#include <dlfcn.h>
#include <sys/mman.h>

#define SERIALNO_TAG "androidboot.serialno="

int main(int argc, char **argv)
{
	int fd_cmdline = open("/proc/cmdline", O_RDONLY);
	int fd = open("/sys/class/android_usb/android0/iSerial", O_RDWR);
	char *p;
	char serialno[32] = {0};
	char cmdline[512] = {0};

	if((fd < 0) || (fd_cmdline < 0)){
		printf("no exist cmdline or iSerial node\n");
		return 1;
	}

	read(fd_cmdline, cmdline, 512);
	p = strstr((char *)cmdline, SERIALNO_TAG);
	if(!p) {
		printf("no serial tag\n");
		return 1;
	}
	p += strlen(SERIALNO_TAG);
	strcpy((char *)serialno, p);
	p = strchr((char *)serialno, '\n');
	if(p)
		*p = 0;
	p = strchr((char *)serialno, '\r');
	if(p)
		*p = 0;

	write(fd, (char *)serialno, strlen((char *)serialno));
	close(fd);
	close(fd_cmdline);
	return 0;
}
